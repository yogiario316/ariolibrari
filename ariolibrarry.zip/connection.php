<?php
$con=mysqli_connect("localhost","root","","toko") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","toko") or die(mysqli_error($con));
?>
